# TRADO — educational multi-market dashboard

TRADO is a beginner-friendly Streamlit dashboard for historical market analysis and **paper simulation only**.

## Safety and scope
This build does not place trades. It has no live-order code, no broker order endpoint, and no live-trading switch. The MT5 connector is **read-only**: it requests candle history from the locally installed MetaTrader 5 terminal. It does not read or use account credentials in the app and does not submit orders.

A demo account is still a broker account. Keep this project in read-only mode and never paste passwords, investor credentials, API keys, or account numbers into the code or chat.

## Features
- Sample data mode (works without a broker)
- Yahoo Finance historical data mode
- Optional MT5 terminal candle-data connector (Windows)
- Moving-average trend display
- RSI (14) indicator
- Paper account curve versus buy-and-hold
- Simulated trade log and CSV export

## Windows 11 setup

### 1. Install Python
Install Python 3.11+ from https://www.python.org/downloads/ and enable **Add Python to PATH**.

### 2. Extract and open
Extract the TRADO ZIP file. Open the `TRADO` folder in VS Code or Command Prompt.

### 3. Create a virtual environment
```bat
py -m venv .venv
.venv\Scripts\activate
```

### 4. Install packages
```bat
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Start TRADO
```bat
python -m streamlit run app.py
```
Open the local URL shown in the terminal, usually `http://localhost:8501`.

## Optional MT5 read-only data
1. Install MetaTrader 5 desktop from your broker's official website.
2. Sign in to a demo account in the MT5 terminal.
3. Keep MT5 open. Check the symbol spelling in Market Watch.
4. In TRADO, select `MetaTrader 5 (read-only)`, enter the symbol and refresh.
5. If the connector package is unavailable for your Python version, use the Python version supported by the MetaTrader5 package or use Sample data mode.

MT5 Python integration is Windows-oriented and requires a locally installed, running terminal. It is not a universal API for Exness web/mobile apps or all brokers. Other platforms need their own official data interfaces.

## Common problems
- `py` not recognised: reinstall Python and enable Add Python to PATH.
- `streamlit` not recognised: activate `.venv` and run `python -m pip install -r requirements.txt`.
- MT5 initialize error: open the desktop terminal and check that it is running.
- Symbol not found: use the exact broker-specific symbol in Market Watch.
- Yahoo data missing: try another ticker or switch to Sample data.

## Files
- `app.py` — dashboard and paper simulator
- `requirements.txt` — packages
- `start_trado.bat` — Windows launcher
