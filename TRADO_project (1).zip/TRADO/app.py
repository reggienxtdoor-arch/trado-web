import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from datetime import datetime, timezone

st.set_page_config(page_title="TRADO", page_icon="📊", layout="wide")

st.title("TRADO")
st.caption("Multi-market learning dashboard • Demo / paper trading only")

st.warning(
    "TRADO is an educational simulator. It does not send orders to a broker and cannot place live trades. "
    "Use demo data only. Market data may be delayed or unavailable."
)

with st.sidebar:
    st.header("Data source")
    source = st.radio("Choose price source", ["Sample data", "Yahoo Finance", "MetaTrader 5 (read-only)"])
    symbol = st.text_input("Symbol", "EURUSD" if source.startswith("MetaTrader") else "AAPL").strip().upper()
    timeframe_label = st.selectbox("MT5 timeframe", ["M5", "M15", "M30", "H1", "H4", "D1"], index=3)
    bars = st.slider("Number of candles", 100, 1500, 500, 50)
    st.divider()
    st.header("Paper strategy")
    fast = st.number_input("Fast moving average", 2, 100, 20)
    slow = st.number_input("Slow moving average", 3, 250, 50)
    starting_balance = st.number_input("Paper balance (USD)", min_value=100.0, value=10000.0, step=500.0)
    fee_pct = st.number_input("Simulated cost per position change (%)", 0.0, 2.0, 0.05, 0.01)
    run = st.button("Refresh data and run", type="primary", use_container_width=True)

if fast >= slow:
    st.error("Fast moving average must be smaller than slow moving average.")
    st.stop()

def sample_data(n, ticker):
    seed = sum(ord(c) for c in ticker) % 10000
    rng = np.random.default_rng(seed)
    returns = rng.normal(0.0002, 0.012, n)
    close = 100 * np.exp(np.cumsum(returns))
    dates = pd.date_range(end=pd.Timestamp.now().floor("h"), periods=n, freq="h")
    return pd.DataFrame({"Date": dates, "Close": close})

def yahoo_data(ticker, n):
    import yfinance as yf
    period = "5d" if n <= 500 else "1mo"
    interval = "5m" if n <= 500 else "30m"
    data = yf.download(ticker, period=period, interval=interval, auto_adjust=True, progress=False)
    if data.empty:
        return pd.DataFrame()
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.get_level_values(0)
    return pd.DataFrame({"Date": data.index, "Close": data["Close"].values}).dropna().tail(n)

def mt5_data(ticker, n, tf):
    try:
        import MetaTrader5 as mt5
    except ImportError:
        raise RuntimeError("MetaTrader5 package is not installed. On Windows, install it with: pip install MetaTrader5")
    timeframe_map = {
        "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
        "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1,
        "H4": mt5.TIMEFRAME_H4, "D1": mt5.TIMEFRAME_D1
    }
    if not mt5.initialize():
        raise RuntimeError(f"Could not connect to the locally installed MT5 terminal: {mt5.last_error()}")
    try:
        if not mt5.symbol_select(ticker, True):
            raise RuntimeError(f"MT5 could not select {ticker}. Check the exact broker symbol in Market Watch.")
        rates = mt5.copy_rates_from_pos(ticker, timeframe_map[tf], 0, int(n))
        if rates is None or len(rates) == 0:
            raise RuntimeError(f"No candles returned for {ticker}: {mt5.last_error()}")
        frame = pd.DataFrame(rates)
        frame["Date"] = pd.to_datetime(frame["time"], unit="s", utc=True).dt.tz_convert(None)
        return frame[["Date", "close"]].rename(columns={"close": "Close"}).dropna()
    finally:
        mt5.shutdown()

if "frame" not in st.session_state or run:
    try:
        with st.spinner("Loading price history..."):
            if source == "Sample data":
                frame = sample_data(bars, symbol or "DEMO")
            elif source == "Yahoo Finance":
                frame = yahoo_data(symbol, bars)
            else:
                frame = mt5_data(symbol, bars, timeframe_label)
        if frame.empty:
            st.error("No price data found. Check the symbol, connection, or data provider.")
            st.stop()
        st.session_state["frame"] = frame
        st.session_state["loaded_source"] = source
        st.session_state["loaded_symbol"] = symbol
    except Exception as exc:
        st.error(str(exc))
        st.info("You can switch to Sample data to explore the dashboard without connecting to a broker.")
        st.stop()

df = st.session_state["frame"].copy()
st.caption(f"Loaded: {st.session_state['loaded_symbol']} • Source: {st.session_state['loaded_source']} • "
           f"Last candle: {pd.to_datetime(df['Date'].iloc[-1]).strftime('%Y-%m-%d %H:%M')}")

df["Fast_MA"] = df["Close"].rolling(int(fast)).mean()
df["Slow_MA"] = df["Close"].rolling(int(slow)).mean()
delta = df["Close"].diff()
gain = delta.clip(lower=0).rolling(14).mean()
loss = (-delta.clip(upper=0)).rolling(14).mean()
rs = gain / loss.replace(0, np.nan)
df["RSI"] = 100 - (100 / (1 + rs))
df["RSI"] = df["RSI"].fillna(50)
df = df.dropna(subset=["Fast_MA", "Slow_MA"]).reset_index(drop=True)

if len(df) < 2:
    st.error("Not enough candles for the selected moving averages.")
    st.stop()

# Educational long/cash-only model. Signals are acted on from the following candle.
df["Signal"] = (df["Fast_MA"] > df["Slow_MA"]).astype(int)
df["Position"] = df["Signal"].shift(1).fillna(0)
df["Return"] = df["Close"].pct_change().fillna(0)
df["Turnover"] = df["Position"].diff().abs().fillna(df["Position"].abs())
df["Paper_Return"] = df["Position"] * df["Return"] - df["Turnover"] * fee_pct / 100
df["TRADO_Equity"] = starting_balance * (1 + df["Paper_Return"]).cumprod()
df["Hold_Equity"] = starting_balance * (1 + df["Return"]).cumprod()

last_price = float(df["Close"].iloc[-1])
equity = float(df["TRADO_Equity"].iloc[-1])
gain_pct = (equity / starting_balance - 1) * 100
state = "PAPER LONG" if int(df["Signal"].iloc[-1]) else "PAPER CASH"

a, b, c, d = st.columns(4)
a.metric("Latest price", f"{last_price:,.5f}")
b.metric("Paper account", f"${equity:,.2f}", f"{gain_pct:+.2f}%")
c.metric("RSI (14)", f"{float(df['RSI'].iloc[-1]):.1f}")
d.metric("Model state", state)

st.subheader("Price and indicators")
fig = go.Figure()
fig.add_trace(go.Scatter(x=df["Date"], y=df["Close"], name="Close"))
fig.add_trace(go.Scatter(x=df["Date"], y=df["Fast_MA"], name=f"MA {fast}"))
fig.add_trace(go.Scatter(x=df["Date"], y=df["Slow_MA"], name=f"MA {slow}"))
fig.update_layout(height=430, hovermode="x unified", xaxis_title="Time", yaxis_title="Price")
st.plotly_chart(fig, use_container_width=True)

st.subheader("Paper account versus buy-and-hold")
fig2 = go.Figure()
fig2.add_trace(go.Scatter(x=df["Date"], y=df["TRADO_Equity"], name="TRADO paper model"))
fig2.add_trace(go.Scatter(x=df["Date"], y=df["Hold_Equity"], name="Buy and hold comparison"))
fig2.update_layout(height=330, hovermode="x unified", xaxis_title="Time", yaxis_title="Account value (USD)")
st.plotly_chart(fig2, use_container_width=True)

st.subheader("Latest paper-trading log")
log = df[["Date", "Close", "Fast_MA", "Slow_MA", "RSI", "Position", "Turnover"]].tail(20).copy()
log["Paper state"] = log["Position"].map({1.0: "Invested (simulated)", 0.0: "Cash (simulated)"})
log["Model event"] = np.where(log["Turnover"] > 0, np.where(log["Position"] > 0, "Paper BUY", "Paper SELL"), "No change")
st.dataframe(log.sort_values("Date", ascending=False), use_container_width=True, hide_index=True)

st.download_button("Download candle and simulation data (CSV)", df.to_csv(index=False).encode("utf-8"),
                   file_name=f"trado_{symbol.lower()}_paper_log.csv", mime="text/csv")

with st.expander("MT5 connection notes"):
    st.markdown("""
    - Install the official MetaTrader 5 desktop terminal and sign in to a **demo account**.
    - Open Market Watch and confirm the exact symbol spelling (for example, some brokers use `EURUSDm`).
    - Select **MetaTrader 5 (read-only)** above and enter that symbol.
    - TRADO only reads candle history from the terminal. It does not access account funds or submit orders.
    - The Python MetaTrader5 package is supported on Windows. This connector is not a universal connector for every trading app.
    """)

with st.expander("What this model does and does not do"):
    st.markdown("""
    **Does:** use a moving-average trend filter, display RSI, and calculate a simplified historical paper result.

    **Does not:** predict prices, guarantee returns, send broker orders, calculate full spread/slippage/tax effects,
    or replace independent testing. Backtests can be misleading and may not represent real execution.
    """)
st.caption("TRADO • Educational software • No broker order execution")
